//index.js
//获取应用实例
const app = getApp()
const apikey = 'eC0OXE0=8g5MOM=lljQgG02Lsjg='
const deviceid = '654479029'
const  device_id='arduinoAndESP8266'
const sendCommandURL = "https://api.heclouds.com/cmds"


Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  ON:function () {
    wx.request({
      url: sendCommandURL + "?device_id=" + deviceid,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": apikey
      },
  
      // data: hardware_id + ":{" + switch_value + "}",      // blueled:{V}, 预感这边可能会有问题
      data: "1" ,
      success(res) {
        console.log("控制成功")
        wx.showToast({
          title: '开启成功',
          icon: 'success',
          duration: 2000
          })
        console.log(res)
        
      }
    })

  },
  OFF:function () {
    wx.request({
      url: sendCommandURL + "?device_id=" + deviceid,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": apikey
      },
      // data: hardware_id + ":{" + switch_value + "}",      //TODO 设计自定义语言 blueled:{V}, 预感这边可能会有问题
      data: "0" ,
      success(res) {
        console.log("控制成功")
        wx.showToast({
          title: '关闭成功',
          icon: 'success',
          duration: 2000
          })
        console.log(res)
      
      }
    })

  }
  }


)
